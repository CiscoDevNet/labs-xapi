const xapi = require('xapi');

//Register to listen for widget events
xapi.event.on('UserInterface Extensions Widget Action', event => {
  
    if ((event.WidgetId == 'button_submit') && (event.Type == 'clicked')){
  
      //Make simultaneous request to retrieve the selected reservation duration and system name  
      Promise.all([ 
        xapi.status.get('UserInterface Extensions Widget 1 Value'),
        xapi.config.get('SystemUnit Name')
        ]).then( values => {
          
          //Calculate start and end times based on the duration          
          let start = new Date();
          let end = new Date( start.getTime() + values[0] * 60000 ); //Duration is the 0th member of the values return array
          //Create a payload object with start/end and room name
          let payload = {
            startTime: start.toISOString(),
            endTime: end.toISOString(),
            roomName: values[1]
          };

          console.log(payload);
          //Execute an HTTP POST to the fake JSONPLaceholder REST API service
          xapi.command('HttpClient Post',
            {
              Header: ['Content-Type: application/json', 'Authorization: Bearer itsme'],
              Url: 'https://jsonplaceholder.typicode.com/posts',
              AllowInsecureHTTPS: 'True'
            },
            JSON.stringify(payload) //Convert the payload object to JSON
          ).then( response => {

            console.log('HTTP request succeeded...');
            
            //If the HTTP request succeeds and has a status code of 201...
            if (response.StatusCode == 201) {
              
              //Pop a confirmation alert message for 5 seconds
              xapi.command('UserInterface Message Alert Display',
                {
                  Title: 'Room Booking',
                  Text: 'This room has been booked for the next ' + values[0] + ' minutes',
                  Duration: 5
                })
            }
          }).catch((err) => {
            
            //If the HTTP request failed, dump error info to the console
            console.log('HTTP request failed...' , err);
          });
        });
    }
});
